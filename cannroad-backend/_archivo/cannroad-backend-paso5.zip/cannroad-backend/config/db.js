// config/db.js — PostgreSQL connection pool
import pg from 'pg';
const { Pool } = pg;

const pool = new Pool({
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 5432,
    user: process.env.DB_USER || 'cannroad_user',
    password: process.env.DB_PASSWORD || 'cannroad_pass',
    database: process.env.DB_NAME || 'cannroad_db',
    max: 20,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 2000,
});

pool.on('error', (err) => {
    console.error('Unexpected error on idle client', err);
});

export default pool;
EOF
echo "✓ config/db.js"