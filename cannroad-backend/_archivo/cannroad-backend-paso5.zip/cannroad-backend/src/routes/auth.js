// src/routes/auth.js — Autenticación JWT
import pool from '../../config/db.js';
import crypto from 'crypto';

export default async function authRoutes(fastify) {
    // POST /api/auth/login
    fastify.post('/login', async (request, reply) => {
        const { email, password } = request.body;

        if (!email || !password) {
            return reply.code(400).send({ error: 'Email y contraseña obligatorios.' });
        }

        try {
            const result = await pool.query(
                `SELECT id, nombre, password_hash, rol, tenant_id 
                 FROM usuarios 
                 WHERE email = $1 AND activo = true LIMIT 1`,
                [email]
            );

            if (result.rows.length === 0) {
                return reply.code(401).send({ error: 'Credenciales inválidas.' });
            }

            const usuario = result.rows[0];
            const hashStored = crypto.createHash('sha256').update(password).digest('hex');
            if (usuario.password_hash !== hashStored) {
                return reply.code(401).send({ error: 'Credenciales inválidas.' });
            }

            const token = fastify.jwt.sign({
                userId: usuario.id,
                email: email,
                rol: usuario.rol,
                tenantId: usuario.tenant_id
            }, { expiresIn: '24h' });

            await pool.query(
                `INSERT INTO audit_log (tenant_id, usuario_id, usuario_email, accion, ip_addr)
                 VALUES ($1, $2, $3, $4, $5)`,
                [usuario.tenant_id, usuario.id, email, 'LOGIN', request.ip]
            );

            return reply.code(200).send({ token, usuario: { id: usuario.id, nombre: usuario.nombre, rol: usuario.rol } });
        } catch (err) {
            fastify.log.error(err);
            return reply.code(500).send({ error: 'Error al autenticar.' });
        }
    });

    // POST /api/auth/validate
    fastify.post('/validate', async (request, reply) => {
        try {
            await request.jwtVerify();
            return { valid: true, user: request.user };
        } catch (err) {
            return reply.code(401).send({ error: 'Token inválido.' });
        }
    });
}
EOF
echo "✓ src/routes/auth.js"