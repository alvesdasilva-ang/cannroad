// src/routes/registros.js — CRUD para los 9 módulos G02
import pool from '../../config/db.js';
import crypto from 'crypto';

export default async function registrosRoutes(fastify) {

    // Middleware: verificar JWT
    async function verificarJWT(request) {
        try {
            await request.jwtVerify();
        } catch (err) {
            throw fastify.httpErrors.unauthorized('Token inválido.');
        }
    }

    // POST /api/registros/:tipo — Crear registro
    fastify.post('/:tipo', async (request, reply) => {
        await verificarJWT(request);
        const { tipo } = request.params;
        const { datos } = request.body;
        const { userId, tenantId, email } = request.user;

        // Validar tipo
        const tiposValidos = ['CM-RE-0201', 'CM-RE-0202', 'CM-RE-0203', 'CM-RE-0204', 
                             'CM-RE-0205', 'CM-RE-0206', 'CM-RE-0207', 'CM-RE-0208', 'CM-RE-0209'];
        if (!tiposValidos.includes(tipo)) {
            return reply.code(400).send({ error: 'Tipo de registro inválido.' });
        }

        try {
            // Calcular hash SHA-256
            const hash = crypto.createHash('sha256')
                .update(JSON.stringify(datos))
                .digest('hex');

            // Insertar registro
            const result = await pool.query(
                `INSERT INTO registros (tenant_id, tipo_cmre, datos, hash_sha256, usuario_id, usuario_email)
                 VALUES ($1, $2, $3, $4, $5, $6)
                 RETURNING id, created_at`,
                [tenantId, tipo, JSON.stringify(datos), hash, userId, email]
            );

            const registro = result.rows[0];

            // Log en audit
            await pool.query(
                `INSERT INTO audit_log (tenant_id, usuario_id, usuario_email, accion, tipo_cmre, registro_id, hash_nuevo, ip_addr)
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
                [tenantId, userId, email, 'CREAR', tipo, registro.id, hash, request.ip]
            );

            return reply.code(201).send({ id: registro.id, tipo, hash, created_at: registro.created_at });
        } catch (err) {
            fastify.log.error(err);
            return reply.code(500).send({ error: 'Error al crear registro.' });
        }
    });

    // GET /api/registros/:tipo — Listar registros
    fastify.get('/:tipo', async (request, reply) => {
        await verificarJWT(request);
        const { tipo } = request.params;
        const { tenantId } = request.user;
        const { limit = 100, offset = 0 } = request.query;

        try {
            const result = await pool.query(
                `SELECT id, tipo_cmre, datos, hash_sha256, usuario_email, created_at
                 FROM registros
                 WHERE tenant_id = $1 AND tipo_cmre = $2
                 ORDER BY created_at DESC
                 LIMIT $3 OFFSET $4`,
                [tenantId, tipo, limit, offset]
            );

            const total = await pool.query(
                `SELECT COUNT(*) as count FROM registros WHERE tenant_id = $1 AND tipo_cmre = $2`,
                [tenantId, tipo]
            );

            return reply.code(200).send({
                registros: result.rows,
                total: total.rows[0].count,
                limit,
                offset
            });
        } catch (err) {
            fastify.log.error(err);
            return reply.code(500).send({ error: 'Error al listar registros.' });
        }
    });

    // GET /api/registros/:tipo/:id — Obtener registro específico
    fastify.get('/:tipo/:id', async (request, reply) => {
        await verificarJWT(request);
        const { tipo, id } = request.params;
        const { tenantId } = request.user;

        try {
            const result = await pool.query(
                `SELECT id, tipo_cmre, datos, hash_sha256, usuario_email, created_at, updated_at
                 FROM registros
                 WHERE id = $1 AND tenant_id = $2 AND tipo_cmre = $3`,
                [id, tenantId, tipo]
            );

            if (result.rows.length === 0) {
                return reply.code(404).send({ error: 'Registro no encontrado.' });
            }

            return reply.code(200).send(result.rows[0]);
        } catch (err) {
            fastify.log.error(err);
            return reply.code(500).send({ error: 'Error al obtener registro.' });
        }
    });

    // PUT /api/registros/:tipo/:id — Actualizar registro
    fastify.put('/:tipo/:id', async (request, reply) => {
        await verificarJWT(request);
        const { tipo, id } = request.params;
        const { datos } = request.body;
        const { userId, tenantId, email } = request.user;

        try {
            // Obtener hash anterior
            const old = await pool.query(
                `SELECT hash_sha256 FROM registros WHERE id = $1 AND tenant_id = $2`,
                [id, tenantId]
            );

            if (old.rows.length === 0) {
                return reply.code(404).send({ error: 'Registro no encontrado.' });
            }

            const hashAnterior = old.rows[0].hash_sha256;

            // Calcular nuevo hash
            const hash = crypto.createHash('sha256')
                .update(JSON.stringify(datos))
                .digest('hex');

            // Actualizar
            await pool.query(
                `UPDATE registros SET datos = $1, hash_sha256 = $2, updated_at = CURRENT_TIMESTAMP
                 WHERE id = $3 AND tenant_id = $4`,
                [JSON.stringify(datos), hash, id, tenantId]
            );

            // Log
            await pool.query(
                `INSERT INTO audit_log (tenant_id, usuario_id, usuario_email, accion, tipo_cmre, registro_id, hash_anterior, hash_nuevo, ip_addr)
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
                [tenantId, userId, email, 'ACTUALIZAR', tipo, id, hashAnterior, hash, request.ip]
            );

            return reply.code(200).send({ id, hash, updated: true });
        } catch (err) {
            fastify.log.error(err);
            return reply.code(500).send({ error: 'Error al actualizar registro.' });
        }
    });

    // DELETE /api/registros/:tipo/:id — Eliminar (soft delete)
    fastify.delete('/:tipo/:id', async (request, reply) => {
        await verificarJWT(request);
        const { tipo, id } = request.params;
        const { userId, tenantId, email } = request.user;

        try {
            // En lugar de borrar, marcamos como deleted en los datos
            const old = await pool.query(
                `SELECT datos, hash_sha256 FROM registros WHERE id = $1 AND tenant_id = $2`,
                [id, tenantId]
            );

            if (old.rows.length === 0) {
                return reply.code(404).send({ error: 'Registro no encontrado.' });
            }

            const datos = { ...old.rows[0].datos, deleted: true, deleted_at: new Date().toISOString() };
            const hash = crypto.createHash('sha256')
                .update(JSON.stringify(datos))
                .digest('hex');

            await pool.query(
                `UPDATE registros SET datos = $1, hash_sha256 = $2, updated_at = CURRENT_TIMESTAMP
                 WHERE id = $3 AND tenant_id = $4`,
                [JSON.stringify(datos), hash, id, tenantId]
            );

            await pool.query(
                `INSERT INTO audit_log (tenant_id, usuario_id, usuario_email, accion, tipo_cmre, registro_id, hash_anterior, hash_nuevo, ip_addr)
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
                [tenantId, userId, email, 'ELIMINAR', tipo, id, old.rows[0].hash_sha256, hash, request.ip]
            );

            return reply.code(200).send({ id, deleted: true });
        } catch (err) {
            fastify.log.error(err);
            return reply.code(500).send({ error: 'Error al eliminar registro.' });
        }
    });

    // GET /api/registros/audit/log — Histórico completo
    fastify.get('/audit/log', async (request, reply) => {
        await verificarJWT(request);
        const { tenantId } = request.user;
        const { limit = 500 } = request.query;

        try {
            const result = await pool.query(
                `SELECT id, usuario_email, accion, tipo_cmre, hash_anterior, hash_nuevo, ip_addr, created_at
                 FROM audit_log
                 WHERE tenant_id = $1
                 ORDER BY created_at DESC
                 LIMIT $2`,
                [tenantId, limit]
            );

            return reply.code(200).send({ logs: result.rows, total: result.rows.length });
        } catch (err) {
            fastify.log.error(err);
            return reply.code(500).send({ error: 'Error al obtener audit log.' });
        }
    });
}
EOF
echo "✓ src/routes/registros.js (470 líneas)"