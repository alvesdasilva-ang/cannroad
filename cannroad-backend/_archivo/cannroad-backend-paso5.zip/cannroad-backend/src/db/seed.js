// src/db/seed.js — Datos iniciales de prueba
import pool from '../../config/db.js';
import crypto from 'crypto';

export async function seedDatabase() {
    const client = await pool.connect();
    try {
        console.log('🌱 Seeding database...');

        // 1. Crear tenant
        const tenantResult = await client.query(
            `INSERT INTO tenants (nombre, empresa, legajo_anmat)
             VALUES ($1, $2, $3)
             ON CONFLICT DO NOTHING
             RETURNING id`,
            ['FIS', 'FIS S.A.S.', '7.563']
        );
        let tenantId;
        if (tenantResult.rows.length > 0) {
            tenantId = tenantResult.rows[0].id;
        } else {
            const existing = await client.query(`SELECT id FROM tenants WHERE legajo_anmat = '7.563' LIMIT 1`);
            tenantId = existing.rows[0].id;
        }

        // 2. Crear usuario admin
        const pwHash = crypto.createHash('sha256').update('naty2024').digest('hex');
        await client.query(
            `INSERT INTO usuarios (tenant_id, email, nombre, password_hash, rol, activo)
             VALUES ($1, $2, $3, $4, $5, $6)
             ON CONFLICT DO NOTHING`,
            [tenantId, 'naty@fis.com.ar', 'Naty Directora', pwHash, 'director_tecnico', true]
        );

        // 3. Crear usuarios de prueba por rol
        const usuarios = [
            { email: 'jefe@fis.com.ar', nombre: 'Juan Jefe', rol: 'jefe_produccion' },
            { email: 'operario@fis.com.ar', nombre: 'Pedro Operario', rol: 'operario_cultivo' },
            { email: 'calidad@fis.com.ar', nombre: 'Rosa Calidad', rol: 'resp_calidad' },
        ];

        for (const u of usuarios) {
            const hash = crypto.createHash('sha256').update('pass1234').digest('hex');
            await client.query(
                `INSERT INTO usuarios (tenant_id, email, nombre, password_hash, rol, activo)
                 VALUES ($1, $2, $3, $4, $5, $6)
                 ON CONFLICT DO NOTHING`,
                [tenantId, u.email, u.nombre, hash, u.rol, true]
            );
        }

        console.log('✓ Seed complete');
    } catch (err) {
        console.error('✗ Seed error:', err.message);
    } finally {
        client.release();
    }
}
EOF
echo "✓ src/db/seed.js"