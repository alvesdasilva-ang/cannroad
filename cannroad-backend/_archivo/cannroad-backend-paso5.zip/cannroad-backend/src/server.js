// src/server.js — Fastify + CannRoad API
import Fastify from 'fastify';
import cors from '@fastify/cors';
import jwt from '@fastify/jwt';
import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import pool from '../config/db.js';
import authRoutes from './routes/auth.js';
import registrosRoutes from './routes/registros.js';
import { seedDatabase } from './db/seed.js';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const fastify = Fastify({ logger: true });

// Plugins
fastify.register(cors, { origin: process.env.CORS_ORIGIN || '*' });
fastify.register(jwt, { secret: process.env.JWT_SECRET || 'dev-secret' });

// Rutas
fastify.register(authRoutes, { prefix: '/api/auth' });
fastify.register(registrosRoutes, { prefix: '/api/registros' });

// Health check
fastify.get('/health', async (request, reply) => {
    try {
        const result = await pool.query('SELECT NOW()');
        return { status: 'ok', db: 'connected', time: result.rows[0].now };
    } catch (err) {
        return { status: 'error', db: 'disconnected', error: err.message };
    }
});

// Ejecutar migraciones al inicio
async function runMigrations() {
    const client = await pool.connect();
    try {
        console.log('🔄 Running migrations...');
        
        await client.query(`
            CREATE TABLE IF NOT EXISTS schema_migrations (
                id SERIAL PRIMARY KEY,
                filename VARCHAR(255) UNIQUE NOT NULL,
                executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);

        const migrationsDir = path.join(__dirname, '../migrations');
        const files = fs.readdirSync(migrationsDir)
            .filter(f => f.endsWith('.sql'))
            .sort();

        for (const file of files) {
            const result = await client.query(
                'SELECT * FROM schema_migrations WHERE filename = $1',
                [file]
            );

            if (result.rows.length === 0) {
                const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf-8');
                console.log(`  → ${file}`);
                await client.query(sql);
                await client.query(
                    'INSERT INTO schema_migrations (filename) VALUES ($1)',
                    [file]
                );
            }
        }

        console.log('✓ Migrations complete');
        
        // Seed de datos
        await seedDatabase();
    } catch (err) {
        console.error('✗ Migration error:', err.message);
        throw err;
    } finally {
        client.release();
    }
}

// Start server
const start = async () => {
    try {
        // Esperar a que PostgreSQL esté listo
        let dbReady = false;
        let attempts = 0;
        while (!dbReady && attempts < 30) {
            try {
                const result = await pool.query('SELECT NOW()');
                dbReady = true;
            } catch (err) {
                attempts++;
                console.log(`Waiting for database... (${attempts}/30)`);
                await new Promise(resolve => setTimeout(resolve, 1000));
            }
        }

        if (!dbReady) {
            throw new Error('Database not ready after 30 seconds');
        }

        // Migraciones
        await runMigrations();

        // Server
        await fastify.listen({ port: process.env.PORT || 3000, host: '0.0.0.0' });
        console.log(`✓ Server running on http://localhost:${process.env.PORT || 3000}`);
    } catch (err) {
        fastify.log.error(err);
        process.exit(1);
    }
};

start();
EOF
echo "✓ src/server.js"